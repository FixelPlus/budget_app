import React, { Component } from 'react'
import './Top.css';

class History extends Component {
    constructor(props) {
        super(props);
    }

    render(){
        return (
            
            <div className='History-component'>
             <button>History</button>
             
            </div>
      
          );
    }
}

export default History;