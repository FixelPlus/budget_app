import React, { Component } from 'react'
import './Top.css';

class Report extends Component {
    constructor(props) {
        super(props);
    }

    render(){
        return (
            
            <div className='Report-component'>
             <button>Report</button>
            </div>
      
          );
    }
}

export default Report;